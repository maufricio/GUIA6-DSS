<?php

class Movie implements sellable{
    private $title;
    private $genre;
    private $num_stock;

    public function __construct($title = "", $genre = "", $num_stock = 0){
        $this->title = $title;
        $this->genre = $genre;
        $this->num_stock = $num_stock;
    }
    public function _setTitle($title){
        $this->title = $title;
    }
    public function _getTitle(){
        return $this->title;
    }
    public function _setGenre($genre){
        $this->genre = $genre;
    }
    public function _getGenre(){
        return $this->genre;
    }
    public function addStock($items){
        $this->num_stock += $items;
    }

    public function sellItem(){
        if($this->num_stock > 0){
            $this->num_stock--;
            return true;
        }else{
            return false;
        }
    }
    public function getStockLevel(){
        return $this->num_stock;
    }
}