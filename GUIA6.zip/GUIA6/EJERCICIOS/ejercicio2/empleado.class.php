<?php
    //definicion de la clase empleado
    class Empleado {
        //Estableciendo las propiedades de la clase
        private static $idEmpleado = 0;
        private $nombre;
        private $apellido;
        private $isss;
        private $renta;
        private $afp;
        private $sueldoNominal;
        private $sueldoLiquido;
        private $pagoHoraExtra;
        private $descuentoPrestamo;
        //Declaracion de constantes para los descuentos del empleado
        //Se inicializan porque pertenecen a la clase
        const descISSS = 0.03;
        const descRENTA = 0.075;
        const descAFP = 0.0625;

        //Constructor de la clase
        function __construct() {
            self::$idEmpleado++;
            $this->nombre = "";
            $this->apellido = "";
            $this->sueldoLiquido = 0.0;
            $this->pagoHoraExtra = 0.0;
            $this->descuentoPrestamo = 0.0;
        }

        //Destructor de la clase
        function __destruct() {
            echo "\n<p class=\"msg\"> El salario y descuentos del empleado han sido calculados. </p>\n";
            $backlink = "<a class=\"a-btn\" href=\"sueldoneto.php\">\n";
            $backlink .= "\t<span class=\"a-btn-symbol\">i</span>\n";
            $backlink .= "\t<span class=\"a-btn-text\">Calcular salario</span>\n";
            $backlink .= "\t<span class=\"a-btn-slide-text\>Otro Empleado</span>\n";
            $backlink .= "\t<span class=\"a-btn-slide-icon\"></span>\n";
            $backlink .= "</a>";
            echo $backlink;
        }

        //Metodos de la clase empleado
        function obtenerSalarioNeto($nombre, $apellido, $salario, $horasextras, $pagohoraextra = 0.0, $prestamoDescuento = 0.0){
            $this->nombre = $nombre;
            $this->apellido = $apellido;
            $this->pagoHoraExtra = $horasextras * $pagohoraextra;
            $this->sueldoNominal = $salario;
            $this->descuentoPrestamo = $prestamoDescuento;

            if($this->pagoHoraExtra > 0){
                $this->isss = ($salario + $this->pagoHoraExtra) * self::descISSS;
                $this->afp = ($salario + $this->pagoHoraExtra) * self::descAFP;
            }else{
                $this->isss = $salario * self::descISSS;
                $this->afp = $salario * self::descAFP;
            }

            //Calcular diferencia de descuento prestamo
            $salariocondescuento = $this->sueldoNominal - ($this->isss + $this->afp + $this->descuentoPrestamo);

            if($salariocondescuento > 2038.10):
                $this->renta = $salariocondescuento * 0.3;
            elseif($salariocondescuento > 895.24 && $salariocondescuento <= 2038.10):
                $this->renta = $salariocondescuento * 0.2;
            elseif($salariocondescuento > 472.00 && $salariocondescuento<=895.24):
                $this->renta = $salariocondescuento * 0.1;
            elseif($salariocondescuento > 0 && $salariocondescuento <= 472.00):
                $this->renta = 0.0;
            else:
                echo "<div><h4>El Salario obtenido es negativo</h4></div>";
            endif;

            $this->sueldoLiquido = $this->sueldoNominal + $this->pagoHoraExtra - ($this->isss + $this->afp + $this->renta + $this->descuentoPrestamo);
            $this->imprimirBoletaPago();
        }

        function imprimirBoletaPago(){
            $tabla = "<table>\n<tr>\n";
            $tabla .= "<td>Id empleado: </td>\n";
            $tabla .= "<td>" . self::$idEmpleado . "</td>\n</tr>\n";
            $tabla .= "<tr>\n<td>Nombre empleado: </td>\n";
            $tabla .= "<td>" . $this->nombre . " " . $this->apellido . "</td>\n</tr>\n";
            $tabla .= "<tr>\n<td>Salario nominal: </td>\n";
            $tabla .= "<td>$ " . number_format($this->sueldoNominal, 2, '.', ',') ."</td>\n</tr>\n";
            $tabla .= "<tr>\n<td>Salario por horas extras: </td>\n";
            $tabla .= "<td>$ " . number_format($this->pagoHoraExtra, 2, '.', ',') ."</td>\n</tr>\n";
            $tabla .= "<tr>\n<td colspan=\"2\">Descuentos</td>\n</tr>\n";
            $tabla .= "<tr>\n<td>Descuento seguro social: </td>\n";
            $tabla .= "<td>$ " . number_format($this->isss, 2, '.', ',') ."</td>\n</tr>\n";
            $tabla .= "<tr>\n<td>Descuento AFP: </td>\n";
            $tabla .= "<td>$ " . number_format($this->afp, 2, '.', ',') . "</td>\n</tr>\n";
            $tabla .= "<tr>\n<td>Descuento renta: </td>\n";
            $tabla .= "<td>$ " . number_format($this->renta, 2, '.', ',') . "</td>\n</tr>";
            $tabla .= "<tr>\n<td>Descuento Prestamos: </td>\n";
            $tabla .= "<td>$ " . number_format($this->descuentoPrestamo, 2, '.', ',') . "</td>\n</tr>";
            $tabla .= "<tr>\n<td>Total descuentos: </td>\n";
            $tabla .= "<td>$ " . number_format($this->isss + $this->afp + $this->renta + $this->descuentoPrestamo,2, '.',',') . "</td>\n</tr>\n";
            $tabla .= "<tr>\n<td>Sueldo líquido a pagar: </td>\n";
            $tabla .= "<td> $" . number_format($this->sueldoLiquido, 2, '.', ',') ."</td>\n</tr>\n";
            $tabla .= "</table>\n";
            echo $tabla;
        }

    }