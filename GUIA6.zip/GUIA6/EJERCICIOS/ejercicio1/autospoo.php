<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Venta de autos</title>
    <link rel="stylesheet" href="css/autospoo.css" />
</head>
<body>
    <header>
        <h1>Autos Disponibles</h1>
    </header>
    <section>

    <div id="formContainer">
        <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST" name="formchooser" id="formchooser">
            <h2>Consultar autos en disponibilidad</h2>
            <select name="selectbrand" id="selectbrand">
                <option disabled selected>Seleccionar</option>
                <option value="Honda">Honda</option>
                <option value="Peugeot">Peugeot</option>
                <option value="Renault">Renault</option>
                <option value="BMW">BMW</option>
            </select>

            <div id="submitfield">
                <input type="submit" name="submitb" id="submitb" value="COTIZAR">
            </div>
        </form>
    </div>
        <article>
            <?php
            
                //Incluyendo el archivo de la clase
                function __autoload($classname){
                    include_once($classname.".class.php");
                }

                //Creando los objetos para cada tipo de auto. Notar que se están
                //asignando a elementos de una matriz que tendrá por nombre $movil

                $movil[0] = new Auto("Peugeot", "307", "Gris", "img/peugeot.jpg");
                $movil[1] = new Auto("Renault", "Clio", "Marron", "img/renaultclio.jpg");
                $movil[2] = new Auto("BMW", "Serie6", "Azul", "img/bmwserie6.jpg");

                //Esta llamada mostrara los valores por defecto en los argumentos
                //del metodo constructor

                $movil[3] = new Auto();

                $brand = filter_input(INPUT_POST, 'selectbrand', FILTER_SANITIZE_STRING);

                if($brand):
                    echo "<p class=\"warning\">You selected: $brand</p>";
                    switch($brand):
                        case "Peugeot":
                            $movil[0]->mostrar();
                        break;
                        case "Renault": 
                            $movil[1]->mostrar();
                        break;
                        case "BMW":
                            $movil[2]->mostrar();
                        break;
                        case "Honda":
                            $movil[3]->mostrar();
                        break;
                    endswitch;
                else:
                    echo "<p class=\"warning\">Did not select any color</p>";
                endif;
            ?>
        </article>
    </section>
</body>
</html>