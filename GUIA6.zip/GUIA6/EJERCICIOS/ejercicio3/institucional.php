<?php

    function __autoload($class_name){
        require("class/" . $class_name . ".class.php");
    }

    //Creando el objeto pagina
    $instituPage = new page();
    $instituPage->content = <<<PAGE

        <div id="contentPage">
            <h1 id="title1">Institucional Universidad Don Bosco</h1>
            <div id='Descripcion'>
                
                <div id="descripcionImg">
                    <img src="img/plaza-de-las-banderas.jpg" id="imageDescripcion">
                </div>
                <div id="descripcionText">
                <h1 id="subtitle1">Presentación Universidad Don Bosco</h1>
                    <p>La Universidad Don Bosco es una institución salesiana de educación superior fundada en 1984,
                        dedicada a la formación integral de la persona humana. Es una referente de El Salvador y 
                        Centroamérica por su modelo educativo e innovación curricular para la formación integral
                         de la persona a través de un enfoque por competencia, la mejora continua y procesos sólidos 
                         de acreditación institucional y de programas, tanto en El Salvador como a nivel internacional.
                    </p>
                </div>
            </div>
            <div id='Descripcion'>
                <div id="descripcionImg">
                    <img src="img/mision-udb.jpg" id="imageDescripcion">
                </div>
                <div id="descripcionText">
                <h1 id="subtitle1">Misión Universidad Don Bosco</h1>
                <p>Somos una institución de educación superior con carisma salesiano dedicada a la formación integral de la persona humana, por medio de la investigación, la ciencia, la cultura, la tecnología, la innovación y el compromiso con la comunidad para la construcción de una sociedad libre, justa y solidaria.</p>
                </div>
            </div>

            <div id='Descripcion'>
                <div id="descripcionImg">
                    <img src="img/vision.jpg" id="imageDescripcion">
                </div>
                <div id="descripcionText">
                <h1 id="subtitle1">Visión Universidad Don Bosco</h1>
                <p>Una universidad salesiana, líder a nivel nacional y referente a nivel regional por su modelo educativo; reconocida por la innovación curricular; por el desarrollo profesional y la internacionalización de sus estudiantes, educadores y personal de gestión; por la ejecución de proyectos de investigación, desarrollo e innovación; por sus publicaciones de impacto; por sus programas de grado y postgrado acreditados internacionalmente; por sus programas a distancia únicos e innovadores; por el mejoramiento continuo de la calidad y por la gestión de sus recursos físicos, tecnológicos y financieros para la sostenibilidad de la institución.</p>
                </div>
            </div>
        </div>

    PAGE;

    echo $instituPage->display();