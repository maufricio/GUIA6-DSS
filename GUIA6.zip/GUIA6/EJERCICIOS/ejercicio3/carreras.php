<?php
include_once 'carrerasStorage.php';
error_reporting();
function __autoload($class_name){
    require("class/". $class_name .".class.php");
}

$carrerapage = new page();
$carrerapage->content .= "<div id='contentCarreras'>";
echo $carrerapage->display();
$carrerapage->content .= recorrerArray($arrayCarreras);
$carrerapage->content .= "</div>";
