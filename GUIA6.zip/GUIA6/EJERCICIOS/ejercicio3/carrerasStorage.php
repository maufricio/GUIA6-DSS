<?php
error_reporting();
$arrayCarreras = array(
    "Técnicos" => array(
        "Tecnico en Ingeniería en Computación" =>  array(
            "Imagen" => "<img src='img/tecnico-compu.jpg'/>",
            "Duracion" => "2 años\n",
            "Descripcion" => "El Tecnico en Ingeniería en Computación, puede desempeñarse en instituciones gubernamentales, 
            empresas de producción tecnológica, comercio, industria, banca, educacion, turismo, comunicaciones y salud.\n",
            "Habilidades" => "1. Desarrollador de soluciones informaticas para plataformas más utilizadas en el mercado nacional e internacional,
            2. Diseñador de experiencias de usuario, 3. Planificador de desarrollo de proyectos de software orientado a la tecnología web y de escritorio, Planificador de redes y de seguridad de redes, Tester de Software\n",
            "Modalidad" => "A Distancia\n",
            "Asignaturas" => "20 asignaturas, 4 ciclos\n"
        )
    ),
    "Ingenierías" => array(
        "Ingeniería en Ciencias de la Computación" => array(
            "Imagen" => "<img src='img/ingenieriaCompu.jpg' />",
            "Duracion" => "5 años",
            "Descripcion" => "El Ingeniero en Ciencias de la Computación de la Universidad Don Bosco estará cualificado para desempeñarse en situaciones complejas en tres ámbitos de actuación:
                el desarrollo de software, la generación de Tecnologías de Información y la gestión de redes y comunicacion de datos.",
            "Habilidades" => "1. Gestiona proyectos informáticos, 2. Crea software innovadores, 3. Gestiona redes informaticas, aplicando normas técnicas internacionales.",
            "Modalidad" => "Híbrido",
            "Asignaturas" => "44 asignaturas, 10 ciclos"
        )
    ),
    "Licenciaturas" => array(

    ),
    "Postgrados y Maestrías" => array(

    )
);

function recorrerArray($array){
    if(is_array($array) || is_object($array)):
        echo "<table id='tablaDisplayingCarreras'>";
            echo "<th>Nombre Carrera</th>";
            echo "<th>Duracion Carrera</th>";
            echo "<th>Descripcion Carrera</th>";
            echo "<th>Habilidades a desarrollar </th>";
            echo "<th>Modalidad de Carrera</th>";
            echo "<th>Asignaturas de Carrera</th>";
        foreach($array as $key){
            echo "<div class='carrera'>";
            
            foreach($key as $keyValue => $valueNameCarrera){
                echo "<tr>";
                echo "<td><p> <strong>Carrera: " . $keyValue . "</strong></p></td>";
                echo "</tr>";
                echo "<tr>";
                    foreach($valueNameCarrera as $valueMajor => $valores){
                        echo "<td><p>" . $valores . "</p><br></td>";           
                    }
                    echo "</tr>";
            }
            echo "</div>";
        }
        echo "</table>";
    endif;
}

?>